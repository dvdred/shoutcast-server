#!/bin/sh
chmod a+x sc_serv
./sc_serv setup